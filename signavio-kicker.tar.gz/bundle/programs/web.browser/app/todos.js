/*
* Notifications
** new mesges
** additional info in gamestart
* !! game end makieren
* !! bdages
** simple login
* chat begrenzen
* !icon favo
*
* config: nachricht wenn frei/ende
** PING button
* link is not deleted
* nicht jeder sollte entfernen können
** REFACTORINGS: 
* template überarbeiten (routes)
*/